import {useState } from "react";

function Counter(props) {
    const [clickA, setClickA] = useState(2);
    const [clickB, setClickB] = useState(1);

    return (
        <div>
            {/*본인이 작성하라*/}

            
        </div>
    );
}

export default Counter;
