import React from "react";

function Component(props) {
    return (
        <div>
            {/*본인이 작성시작*/}
            
            {/*본인이 작성종료*/}
        </div>
    );
}

export default Component;